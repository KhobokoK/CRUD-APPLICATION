const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        // Connect to MongoDB using the provided URI
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });

        // Parse the connection string to remove the password
        const connectionStringWithoutPassword = process.env.MONGO_URI.replace(/\/\/[^:]+:[^@]+@/, '//');

        // Log the connection string without the password along with the success message
        console.log(`MongoDB Connected: ${connectionStringWithoutPassword}`);
    } catch (error) {
        console.error("Error connecting to MongoDB:", error.message);
        process.exit(1); // Exit process with failure
    }
}

module.exports = connectDB;
